﻿using System;
using System.Collections.Generic;

#nullable disable

namespace sklad1.Models
{
    public partial class Supplier
    {
        public Supplier()
        {
            Products = new HashSet<Product>();
        }

        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public bool IsConstant { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}
