﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using sklad1.Models; // Подключаем базу данных, чтобы программа видела таблицы

namespace sklad1.Forms
{
    public partial class ProductAddForm : Form
    {
        // ИСПРАВЛЕНО: Имя конструктора теперь совпадает с именем класса!
        public ProductAddForm()
        {
            InitializeComponent();
            this.Text = "Добавление нового товара";
        }

        // Событие загрузки самой формы
        private void ProductAddForm_Load(object sender, EventArgs e)
        {
            LoadSuppliers(); // Заполняем выпадающий список поставщиков при открытии
            numPrice.Value = 0;
            numStock.Value = 0;
        }

        // Метод для загрузки поставщиков из базы данных
        private void LoadSuppliers()
        {
            using (var db = new sklad_bd_1Context())
            {
                cbSupplier.DataSource = db.Suppliers.ToList();
                cbSupplier.DisplayMember = "SupplierName";
                cbSupplier.ValueMember = "SupplierId";
            }
        }

        // ИСПРАВЛЕНО: Логика кнопки "Добавить товар" (бывшая button1_Click)
        private void btnSave_Click(object sender, EventArgs e)
        {
            // Проверяем, ввёл ли пользователь название товара
            if (string.IsNullOrWhiteSpace(tbProductName.Text))
            {
                MessageBox.Show("Пожалуйста, введите наименование товара!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var db = new sklad_bd_1Context())
            {
                // Создаем новый товар из полей формы
                Product newProduct = new Product
                {
                    ProductName = tbProductName.Text.Trim(),
                    Category = tbCategory.Text.Trim(),
                    UnitOfMeasure = tbUnit.Text.Trim(),
                    PricePerUnit = numPrice.Value,
                    StockQuantity = (int)numStock.Value,
                    SupplierId = (int)cbSupplier.SelectedValue,
                    ArrivalDate = DateTime.Now // Сегодняшняя дата
                };

                // Автоматически выставляем статус в зависимости от количества
                if (newProduct.StockQuantity == 0) newProduct.Status = "Нет";
                else if (newProduct.StockQuantity <= 10) newProduct.Status = "Мало";
                else newProduct.Status = "В наличии";

                db.Products.Add(newProduct); // Добавляем в контекст
                db.SaveChanges(); // Сохраняем изменения в саму БД
            }

            MessageBox.Show("Новый товар успешно добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK; // Говорим MainForm, что всё прошло успешно
            this.Close(); // Закрываем форму добавления
        }
    }
}