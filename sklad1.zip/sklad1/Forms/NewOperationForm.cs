﻿using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using sklad1.Models;

namespace sklad1.Forms
{
    public partial class NewOperationForm : Form
    {
        private int _productId;
        private Product _product;
        private Supplier _supplier;

        public NewOperationForm(int productId)
        {
            InitializeComponent();
            _productId = productId;
            this.Text = "Оформление складской операции";
        }

        // Загрузка данных при открытии формы
        private void NewOperationForm_Load(object sender, EventArgs e)
        {
            LoadData();
            cbOperationType.SelectedIndex = 0; // По умолчанию "Поступление"

            // Привязываем автоматический пересчет при изменении количества или типа операции
            numQuantity.ValueChanged += CalculateCosts;
            cbOperationType.SelectedIndexChanged += CalculateCosts;
        }

        private void LoadData()
        {
            using (var db = new sklad_bd_1Context())
            {
                // Загружаем товар и его поставщика, чтобы узнать, постоянный ли он
                _product = db.Products.Include(p => p.Supplier).FirstOrDefault(p => p.ProductId == _productId);
                if (_product == null)
                {
                    MessageBox.Show("Товар не найден!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                _supplier = _product.Supplier;
                lblProductName.Text = _product.ProductName;

                // Загружаем сотрудников в выпадающий список
                cbEmployee.DataSource = db.Employees.ToList();
                cbEmployee.DisplayMember = "FullName";
                cbEmployee.ValueMember = "EmployeeId";
            }
        }

        // ПОДКЛЮЧЕНИЕ БАЗЫ И РАСЧЕТ СТОИМОСТИ В ВИДЕ ФУНКЦИИ (Задание №2)
        private (decimal baseCost, int discountPercent, decimal finalCost) CalculateDiscountedCost(decimal price, int quantity, string operationType, bool isConstantSupplier)
        {
            decimal baseCost = price * quantity;
            int discountPercent = 0;

            // Скидки считаются ТОЛЬКО при выдаче товаров со склада
            if (operationType == "Выдача")
            {
                // 1. Скидка за объем суммы
                if (baseCost > 50000)
                {
                    discountPercent = 10;
                }
                else if (baseCost > 10000)
                {
                    discountPercent = 5;
                }

                // 2. Дополнительная скидка за постоянного контрагента
                if (isConstantSupplier)
                {
                    discountPercent += 5;
                }
            }

            // Расчет итоговой стоимости
            decimal discountAmount = baseCost * ((decimal)discountPercent / 100);
            decimal finalCost = baseCost - discountAmount;

            return (baseCost, discountPercent, finalCost);
        }

        // Метод обработки события для вывода расчёта на экран в реальном времени
        private void CalculateCosts(object sender, EventArgs e)
        {
            if (_product == null || cbOperationType.SelectedItem == null) return;

            int quantity = (int)numQuantity.Value;
            string opType = cbOperationType.SelectedItem.ToString();
            bool isConstant = _supplier?.IsConstant ?? false;

            // Вызываем нашу функцию расчета
            var result = CalculateDiscountedCost(_product.PricePerUnit, quantity, opType, isConstant);

            // --- ОБНОВЛЕННЫЕ ИМЕНА МЕТОК С УЧЕТОМ ТВОЕЙ ФОРМЫ ---
            if (opType == "Выдача")
            {
                lblDiscountInfo1.Text = $"Базовая сумма: {result.baseCost:F2} руб.\nСкидка: {result.discountPercent}% " +
                                       (isConstant ? "(в т.ч. +5% за постоянного партнёра)" : "");
            }
            else
            {
                lblDiscountInfo1.Text = "При поступлении товара скидки не применяются.";
            }

            lblTotalCost.Text = $"{result.finalCost:F2} руб.";
        }

        // Кнопка "Провести операцию" — СВЯЗАЛИ НАПРЯМУЮ С ИНТЕРФЕЙСОМ (Дописали _1)
        private void btnExecute_Click_1(object sender, EventArgs e)
        {
            int reqQuantity = (int)numQuantity.Value;
            string opType = cbOperationType.SelectedItem.ToString();

            // Валидация остатков при выдаче (Задание №1 — контроль остатков)
            if (opType == "Выдача" && reqQuantity > _product.StockQuantity)
            {
                MessageBox.Show($"Недостаточно товара на складе!\nДоступно: {_product.StockQuantity} шт., требуется: {reqQuantity} шт.",
                                "Ошибка контроля остатков", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var db = new sklad_bd_1Context())
            {
                bool isConstant = _supplier?.IsConstant ?? false;
                var costResult = CalculateDiscountedCost(_product.PricePerUnit, reqQuantity, opType, isConstant);

                // 1. Создаем и сохраняем операцию в историю
                WarehouseOperation op = new WarehouseOperation
                {
                    ProductId = _productId,
                    EmployeeId = (int)cbEmployee.SelectedValue,
                    OperationType = opType,
                    Quantity = reqQuantity,
                    OperationDate = DateTime.Now,
                    BaseCost = costResult.baseCost,
                    DiscountPercent = costResult.discountPercent,
                    TotalCost = costResult.finalCost
                };
                db.WarehouseOperations.Add(op);

                // 2. Корректируем остатки товара на складе (Задание №1)
                var productInDb = db.Products.Find(_productId);
                if (opType == "Поступление")
                {
                    productInDb.StockQuantity += reqQuantity;
                }
                else // Выдача
                {
                    productInDb.StockQuantity -= reqQuantity;
                }

                // Автоматическое управление статусом наличия по ТЗ
                if (productInDb.StockQuantity == 0) productInDb.Status = "Нет";
                else if (productInDb.StockQuantity <= 10) productInDb.Status = "Мало";
                else productInDb.Status = "В наличии";

                db.SaveChanges();
            }

            MessageBox.Show("Операция успешно проведена и внесена в базу!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}