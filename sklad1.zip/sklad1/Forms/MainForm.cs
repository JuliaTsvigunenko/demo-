﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using sklad1.Models;

namespace sklad1.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            this.Text = "Склад предприятия — Учёт товаров";
        }

        // Загрузка формы
        // Загрузка формы
        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadProductsData();

            // ЖЕЛЕЗНАЯ ПРИВЯЗКА СОБЫТИЯ КОДОМ:
            dgvProducts.SelectionChanged += dgvProducts_SelectionChanged;
        }

        // Загрузка товаров в верхнюю таблицу
        public void LoadProductsData()
        {
            using (var db = new sklad_bd_1Context())
            {
                var productsList = db.Products
                    .Include(p => p.Supplier)
                    .Select(p => new
                    {
                        ID = p.ProductId, // Имя колонки теперь "ID"
                        Наименование = p.ProductName,
                        Категория = p.Category,
                        Ед_Измерения = p.UnitOfMeasure,
                        Остаток_На_Складе = p.StockQuantity,
                        Цена_За_Единицу = p.PricePerUnit,
                        Поставщик = p.Supplier.SupplierName,
                        Дата_Поступления = p.ArrivalDate.ToShortDateString(),
                        Статус = p.Status
                    })
                    .ToList();

                dgvProducts.DataSource = productsList;
            }
        }

        // Событие смены выбранного товара — вывод истории движений
        private void dgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            // Проверяем, что в таблице товаров вообще выделена строка
            if (dgvProducts.SelectedRows.Count == 0) return;

            // ИСПРАВЛЕНО: Берем "ID", так как в Select выше колонка названа именно так
            if (dgvProducts.SelectedRows[0].Cells["ID"].Value == null) return;
            int productId = Convert.ToInt32(dgvProducts.SelectedRows[0].Cells["ID"].Value);

            using (var db = new sklad_bd_1Context())
            {
                // Загружаем историю ТОЛЬКО для этого товара и подтягиваем ФИО сотрудника
                var history = db.WarehouseOperations
                    .Include(o => o.Employee)
                    .Where(o => o.ProductId == productId)
                    .OrderByDescending(o => o.OperationDate) // Свежие операции сверху
                    .Select(o => new
                    {
                        ID_Операции = o.OperationId,
                        Тип = o.OperationType,
                        Количество = o.Quantity,
                        Дата = o.OperationDate.ToString("dd.MM.yyyy HH:mm"),
                        Сотрудник = o.Employee != null ? o.Employee.FullName : "Не указан",
                        Сумма = o.TotalCost
                    })
                    .ToList();

                // Выводим в таблицу истории
                dgvOperations.DataSource = history;
            }
        }

        // Логика кнопки "Новая операция"
        private void btnNewOperation_Click(object sender, EventArgs e)
        {
            // Проверяем, выделил ли пользователь товар для операции
            if (dgvProducts.CurrentRow == null)
            {
                MessageBox.Show("Выберите товар из списка для оформления операции!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int productId = (int)dgvProducts.CurrentRow.Cells["ID"].Value;

            // Открываем форму проведения операции
            using (NewOperationForm opForm = new NewOperationForm(productId))
            {
                if (opForm.ShowDialog() == DialogResult.OK)
                {
                    // Обновляем таблицу товаров на лету
                    LoadProductsData();

                    // ДОБАВЛЕНО: Принудительно обновляем историю, чтобы только что проведенная операция сразу появилась на экране
                    dgvProducts_SelectionChanged(this, EventArgs.Empty);
                }
            }
        }

        private void dgvOperations_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        // Логика кнопки "Добавить товар"
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            using (ProductEditForm addForm = new ProductEditForm())
            {
                if (addForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProductsData();
                }
            }
        }

        // Логика кнопки "Редактировать товар"
        private void btnEditProduct_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите товар из списка для редактирования!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int productId = (int)dgvProducts.CurrentRow.Cells["ID"].Value;

            using (ProductEditForm editForm = new ProductEditForm(productId))
            {
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProductsData();
                    dgvProducts_SelectionChanged(this, EventArgs.Empty);
                }
            }
        }

        private void dgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAddProduct_Click_1(object sender, EventArgs e)
        {

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            // 1. Проверяем, выбрана ли строка
            if (dgvProducts.CurrentRow == null)
            {
                MessageBox.Show("Пожалуйста, выберите товар в таблице для удаления!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. БЕЗОПАСНЫЙ СПОСОБ: вытаскиваем сам объект Product из привязанной строки
            var selectedRow = dgvProducts.CurrentRow.DataBoundItem as Product;

            // На случай, если данные привязаны через BindingSource, проверяем еще один вариант:
            if (selectedRow == null && dgvProducts.CurrentRow.DataBoundItem is DataRowView rowView)
            {
                // Если вдруг используется стандартный DataTable
                int id = Convert.ToInt32(rowView["ProductId"]);
                ExecuteDelete(id, rowView["ProductName"].ToString());
                return;
            }

            if (selectedRow != null)
            {
                // Вызываем метод удаления, передавая ID и Имя из объекта
                ExecuteDelete(selectedRow.ProductId, selectedRow.ProductName);
            }
            else
            {
                // 3. РЕЗЕРВНЫЙ СПОСОБ: если объект не извлекся, берем по НАПРАВЛЕННОМУ ИНДЕКСУ (обычно ID идет первой колонкой - индекс 0)
                try
                {
                    int id = Convert.ToInt32(dgvProducts.CurrentRow.Cells[0].Value);
                    string name = dgvProducts.CurrentRow.Cells[1].Value?.ToString() ?? "Товар";
                    ExecuteDelete(id, name);
                }
                catch
                {
                    MessageBox.Show("Не удалось определить ID выбранного товара. Проверьте структуру таблице.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Вынесли логику удаления в отдельный красивый метод (эксперты на экзамене это любят)
        /// <summary>
        /// 
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="productName"></param>
        private void ExecuteDelete(int productId, string productName)
        {
            DialogResult result = MessageBox.Show(
                $"Вы чётко уверены, что хотите полностью удалить товар \"{productName}\" из базы данных?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    using (var db = new sklad_bd_1Context())
                    {
                        var productInDb = db.Products.Find(productId);
                        if (productInDb != null)
                        {
                            db.Products.Remove(productInDb);
                            db.SaveChanges();

                            MessageBox.Show("Товар успешно удален!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadProductsData(); // Обновляем таблицу на главной
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Не удалось удалить товар. Возможно, по нему есть операции!\nОшибка: {ex.Message}",
                                    "Критическая ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


    }
}