﻿using System;
using System.Linq;
using System.Windows.Forms;
using sklad1.Models;

namespace sklad1.Forms
{
    public partial class ProductEditForm : Form
    {
        private int? _productId; // Если null — мы добавляем новый товар, если есть число — редактируем старый

        // Конструктор №1: вызывается при ДОБАВЛЕНИИ нового товара
        public ProductEditForm()
        {
            InitializeComponent();
            _productId = null;
            this.Text = "Добавление товара";

            LoadSuppliers();
            cbStatus.SelectedIndex = 0; // По умолчанию выбираем первый статус ("В наличии")
        }

        // Конструктор №2: вызывается при РЕДАКТИРОВАНИИ существующего товара
        public ProductEditForm(int productId)
        {
            InitializeComponent();
            _productId = productId;
            this.Text = "Редактирование товара";

            LoadSuppliers();
            LoadProductData();
        }

        // Метод автоматической загрузки списка поставщиков из базы данных в выпадающий список
        private void LoadSuppliers()
        {
            using (var db = new sklad_bd_1Context())
            {
                cbSupplier.DataSource = db.Suppliers.ToList();
                cbSupplier.DisplayMember = "SupplierName"; // Что видит пользователь на экране
                cbSupplier.ValueMember = "SupplierId";     // Какой ID уходит в базу данных
            }
        }

        // Автоматическая подгрузка данных изменяемого товара в поля формы (Задание №3)
        private void LoadProductData()
        {
            using (var db = new sklad_bd_1Context())
            {
                var product = db.Products.Find(_productId);
                if (product != null)
                {
                    tbProductName.Text = product.ProductName;
                    tbCategory.Text = product.Category;
                    tbUnitOfMeasure.Text = product.UnitOfMeasure;
                    numStockQuantity.Value = product.StockQuantity;
                    numPricePerUnit.Value = product.PricePerUnit;
                    cbSupplier.SelectedValue = product.SupplierId;
                    dtpArrivalDate.Value = product.ArrivalDate;
                    cbStatus.SelectedItem = product.Status;
                }
            }
        }

        // Логика кнопки "Сохранить" с валидацией данных (Задание №3)
        private void btnSave_Click(object sender, EventArgs e)
        {
            // --- ВСТРОЕННАЯ ОБРАБОТКА ОШИБОК (Валидация по требованиям ТЗ) ---

            if (string.IsNullOrWhiteSpace(tbProductName.Text))
            {
                MessageBox.Show("Наименование товара не может быть пустым!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(tbCategory.Text))
            {
                MessageBox.Show("Поле 'Категория' должно быть заполнено!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(tbUnitOfMeasure.Text))
            {
                MessageBox.Show("Укажите единицу измерения товара!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (numStockQuantity.Value < 0)
            {
                MessageBox.Show("Количество товара на складе не может быть отрицательным!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (numPricePerUnit.Value <= 0)
            {
                MessageBox.Show("Цена за единицу должна быть больше нуля!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // --- КОНЕЦ ВАЛИДАЦИИ — СОХРАНЕНИЕ В БАЗУ ДАННЫХ ---

            using (var db = new sklad_bd_1Context())
            {
                Product product;

                if (_productId == null)
                {
                    // Режим добавления: создаем чистый объект товара
                    product = new Product();
                    db.Products.Add(product);
                }
                else
                {
                    // Режим редактирования: находим этот товар в базе по его ID
                    product = db.Products.Find(_productId);
                }

                // Переносим данные из заполненных нами полей в объект товара
                product.ProductName = tbProductName.Text.Trim();
                product.Category = tbCategory.Text.Trim();
                product.UnitOfMeasure = tbUnitOfMeasure.Text.Trim();
                product.StockQuantity = (int)numStockQuantity.Value;
                product.PricePerUnit = numPricePerUnit.Value;
                product.SupplierId = (int)cbSupplier.SelectedValue;
                product.ArrivalDate = dtpArrivalDate.Value;
                product.Status = cbStatus.SelectedItem.ToString();

                // Сохраняем все изменения в PostgreSQL
                db.SaveChanges();
            }

            MessageBox.Show("Данные успешно сохранены в базе!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK; // Сигнализируем главному окну, что всё прошло успешно
            this.Close(); // Закрываем форму
        }
    }
}