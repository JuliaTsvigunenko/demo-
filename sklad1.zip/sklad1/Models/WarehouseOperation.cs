﻿using System;
using System.Collections.Generic;

#nullable disable

namespace sklad1.Models
{
    public partial class WarehouseOperation
    {
        public int OperationId { get; set; }
        public int ProductId { get; set; }
        public int EmployeeId { get; set; }
        public string OperationType { get; set; }
        public int Quantity { get; set; }
        public DateTime OperationDate { get; set; }
        public decimal BaseCost { get; set; }
        public int DiscountPercent { get; set; }
        public decimal TotalCost { get; set; }

        public virtual Employee Employee { get; set; }
        public virtual Product Product { get; set; }
    }
}
