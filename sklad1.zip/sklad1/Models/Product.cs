﻿using System;
using System.Collections.Generic;

#nullable disable

namespace sklad1.Models
{
    public partial class Product
    {
        public Product()
        {
            WarehouseOperations = new HashSet<WarehouseOperation>();
        }

        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public string UnitOfMeasure { get; set; }
        public int StockQuantity { get; set; }
        public decimal PricePerUnit { get; set; }
        public int SupplierId { get; set; }
        public DateTime ArrivalDate { get; set; }
        public string Status { get; set; }

        public virtual Supplier Supplier { get; set; }
        public virtual ICollection<WarehouseOperation> WarehouseOperations { get; set; }
    }
}
