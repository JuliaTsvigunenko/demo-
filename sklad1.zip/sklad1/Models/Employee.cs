﻿using System;
using System.Collections.Generic;

#nullable disable

namespace sklad1.Models
{
    public partial class Employee
    {
        public Employee()
        {
            WarehouseOperations = new HashSet<WarehouseOperation>();
        }

        public int EmployeeId { get; set; }
        public string FullName { get; set; }
        public string Position { get; set; }
        public string Phone { get; set; }

        public virtual ICollection<WarehouseOperation> WarehouseOperations { get; set; }
    }
}
